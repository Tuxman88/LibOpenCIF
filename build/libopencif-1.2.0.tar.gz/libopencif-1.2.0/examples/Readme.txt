Examples folder
===============

These examples are very basic examples of how to use the elements provided.
The examples are running over real-life CIF files taken from the Alliance
VLSI applications (open source).

There are two program files here:

   - linux-version.cc: Code intented to show a basic usage of the library on
                       GNU/Linux and Mac OS X systems.
                       
   - twofile-version.cc Code intented to show how to use the two-file version
                        of the library in Windows systems.
                        
Open the source files to know how to compile and run them.

